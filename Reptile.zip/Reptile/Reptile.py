import time
from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.firefox.options import Options
import time

# """
# # 获取序列
# chrome_options = Options()
# 设置chrome浏览器无界面模式
# chrome_options.add_argument('--headless')
# browser = webdriver.Chrome()

firefox_options = Options()
# firefox_options.add_argument('--headless')
browser = webdriver.Firefox()
# browser.get('https://genome.ucsc.edu/cgi-bin/hgc?hgsid=980835671_94EZ2QKv7IVD2zwiYjmRYXEiviPb&o=56694975&g=getDna&i=mixed&c=chr12&l=56694975&r=56714605&db=mm10&hgsid=980835671_94EZ2QKv7IVD2zwiYjmRYXEiviPb')
# browser.get('http://genome.ucsc.edu/cgi-bin/hgc?hgsid=1303899299_pOtUOLJDraShjqFa2NF91vEdagaa&o=15560137&g=getDna&i=mixed&c=chrX&l=15560137&r=15602945&db=hg38&hgsid=1303899299_pOtUOLJDraShjqFa2NF91vEdagaa')
browser.get('http://genome.ucsc.edu/cgi-bin/hgc?hgsid=1303899299_pOtUOLJDraShjqFa2NF91vEdagaa&o=15578260&g=getDna&i=mixed&c=chrX&l=15578260&r=15621068&db=hg19&hgsid=1303899299_pOtUOLJDraShjqFa2NF91vEdagaa')
file_1 = open('.\Data_ConsRM.txt')
file_2 = file_1.readlines()
file_3 = open('.\Data_ConsRM1.txt', 'w')
judge = False
num_ = 0
for i in file_2:
    num_ += 1
    # print(num_)
    # print(i)
    f = i.split('	')
    # print(f)
    position = f[2].split(':')[1]

    # # if f[5] == "+":
    qujian = f[2] + "-" + position
    # print(f[5])

    input_1 = browser.find_element_by_id('getDnaPos')
    input_1.clear()
    input_1.send_keys(qujian)
    input_2 = browser.find_element_by_id('hgSeq.padding5')
    input_2.clear()
    input_2.send_keys('20')
    input_3 = browser.find_element_by_id('hgSeq.padding3')
    input_3.clear()
    input_3.send_keys('20')
    if judge == True:
        check = browser.find_element_by_name("hgSeq.revComp")
        check.click()
        judge = False
    if f[3] == "-":
        judge = True
        check = browser.find_element_by_name("hgSeq.revComp")
        check.click()
        button = browser.find_element_by_id('submit')
        button.click()
        while True:
            try:
                output = browser.find_element_by_tag_name('pre')
                break
            except:
                print("数据请求超时，2s后再次尝试")
                time.sleep(2)
        # print(output.text)
        file_3.write(output.text)
        file_3.write('\n')
        # time.sleep(1)
        browser.back()

    if f[3] == "+":
        check = browser.find_element_by_name("hgSeq.revComp")
        button = browser.find_element_by_id('submit')
        button.click()
        # time.sleep(0.5)
        while True:
            try:
                output = browser.find_element_by_tag_name('pre')
                break
            except:
                print("数据请求超时，2s后再次尝试")
                time.sleep(2)
        file_3.write(output.text)
        file_3.write('\n')
        # time.sleep(1)
        browser.back()


file_3.close()
