from tensorflow.keras.models import load_model
import numpy as np
from sklearn.metrics import auc,roc_curve,confusion_matrix
from Bio import SeqIO
import pandas as pd
import argparse
import os




def calc(TN, FP, FN, TP):
    SN = TP / (TP + FN)
    SP = TN / (TN + FP)
    Precision = TP / (TP + FP)
    ACC = (TP + TN) / (TP + TN + FN + FP)
    F1 = (2 * TP) / (2 * TP + FP + FN)
    MCC = (TP * TN - FP * FN) / pow((TP + FN) * (TP + FP) * (TN + FP) * (TN + FN), 0.5)
    return SN, SP, ACC, MCC


def RE_chemical_properties(AA):
    one_hot_dict = {
        'A': [0, 1, 0],
        'C': [1, 0, 0],
        'G': [0, 0, 1],
        'U': [1, 1, 1]
    }
    coding_arr = np.zeros((len(AA), 4), dtype=float)
    # for m in range(len(AA)):
    A_num = 0
    C_num = 0
    G_num = 0
    T_num = 0
    All_num = 0
    for x in AA:
        if x == "A":
            All_num += 1
            A_num += 1
            Density = A_num/All_num
            coding_arr[All_num-1] = one_hot_dict[AA[All_num-1]] + [Density]
        if x == "C":
            All_num += 1
            C_num += 1
            Density = C_num/All_num
            coding_arr[All_num-1] = one_hot_dict[AA[All_num-1]] + [Density]
        if x == "G":
            All_num += 1
            G_num += 1
            Density = G_num/All_num
            coding_arr[All_num-1] = one_hot_dict[AA[All_num-1]] + [Density]
        if x == "U":
            All_num += 1
            T_num += 1
            Density = T_num/All_num
            coding_arr[All_num-1] = one_hot_dict[AA[All_num-1]] + [Density]

        # print(coding_arr)
    return coding_arr

def AA_ONE_HOT(AA):
    one_hot_dict = {
        'A': [1, 0, 0, 0],
        'C': [0, 1, 0, 0],
        'G': [0, 0, 1, 0],
        'U': [0, 0, 0, 1]
    }
    coding_arr = np.zeros((len(AA), 4), dtype=float)
    for m in range(len(AA)):
        coding_arr[m] = one_hot_dict[AA[m]]

    return coding_arr

def RE_AA_ONE_HOT(AA):
    one_hot_dict = {
        'A': [0, 0, 0, 1],
        'C': [0, 0, 1, 0],
        'G': [0, 1, 0, 0],
        'U': [1, 0, 0, 0]
    }
    coding_arr = np.zeros((len(AA), 4), dtype=float)
    for m in range(len(AA)):
        coding_arr[m] = one_hot_dict[AA[m]]

    return coding_arr


def chemical_properties(AA):
    one_hot_dict = {
        'A': [1, 1, 1],
        'C': [0, 0, 1],
        'G': [1, 0, 0],
        'U': [0, 1, 0]
    }
    coding_arr = np.zeros((len(AA), 4), dtype=float)
    # for m in range(len(AA)):
    A_num = 0
    C_num = 0
    G_num = 0
    U_num = 0
    All_num = 0
    for x in AA:
        if x == "A":
            All_num += 1
            A_num += 1
            Density = A_num/All_num
            coding_arr[All_num-1] = one_hot_dict[AA[All_num-1]] + [Density]
        if x == "C":
            All_num += 1
            C_num += 1
            Density = C_num/All_num
            coding_arr[All_num-1] = one_hot_dict[AA[All_num-1]] + [Density]
        if x == "G":
            All_num += 1
            G_num += 1
            Density = G_num/All_num
            coding_arr[All_num-1] = one_hot_dict[AA[All_num-1]] + [Density]
        if x == "U":
            All_num += 1
            U_num += 1
            Density = U_num/All_num
            coding_arr[All_num-1] = one_hot_dict[AA[All_num-1]] + [Density]

        # print(coding_arr)
    return coding_arr


def get_file_feature(m6A_save_path):


    AA_all = []
    id_all = []

    seq = SeqIO.parse(m6A_save_path, 'fasta')
    aa = len(list(seq))
    i = 0
    p = np.zeros((aa, 41, 4))
    pp = p.copy()
    pp2 = p.copy()
    pp3 = p.copy()
    pp4 = p.copy()
    for my_pp in SeqIO.parse(m6A_save_path,'fasta'):
        id = my_pp.id
        id_all.append(id)
        AA = str(my_pp.seq)
        AA_all.append(AA)
        pp[i] = chemical_properties(AA)
        pp2[i] = RE_chemical_properties(AA)
        pp3[i] = AA_ONE_HOT(AA)
        pp4[i] = RE_AA_ONE_HOT(AA)

        i += 1

    xx_all = np.concatenate((pp, pp2, pp3, pp4), axis=2)
#    print(xx_all.shape)
    return xx_all, id_all



def get_predictor(train_,m6A_save_path,model_path):
    TN, FP, FN, TP, AUC = [], [], [], [], []

    model1 = load_model(train_ + '1.h5')

    x_test1, id_all = get_file_feature(m6A_save_path)

    y_predict1 = model1.predict(x_test1)

    probs = y_predict1[:, 0]

    prediction_labels_1 = np.argmin(y_predict1, axis=1)


    model2 = load_model(train_ + '2.h5')
    x_test2, id_all = get_file_feature(m6A_save_path)

    y_predict2 = model2.predict(x_test2)
    probs += y_predict2[:, 0]

    prediction_labels_2 = np.argmin(y_predict2, axis=1)




    model3 = load_model(train_ + '3.h5')
    x_test3, id_all = get_file_feature(m6A_save_path)

    y_predict3 = model3.predict(x_test3)
    probs += y_predict3[:, 0]

    prediction_labels_3 = np.argmin(y_predict3, axis=1)




    model4 = load_model(train_ + '4.h5')
    x_test4, id_all = get_file_feature(m6A_save_path)

    y_predict4 = model4.predict(x_test4)
    probs += y_predict4[:, 0]

    prediction_labels_4 = np.argmin(y_predict4, axis=1)


    model5 = load_model(train_ + '5.h5')
    x_test5, id_all = get_file_feature(m6A_save_path)

    y_predict5 = model5.predict(x_test5)
    probs += y_predict5[:, 0]
    prediction_labels_5 = np.argmin(y_predict5, axis=1)

    probs = (probs / 5).flatten().tolist()
    write_tp = []
    prediction_labels_end = []
    for num in range(len(x_test1)):
        judge = prediction_labels_1[num] + prediction_labels_2[num] + prediction_labels_3[num] + prediction_labels_4[
            num] + prediction_labels_5[num]
        if judge > 2.5:
            prediction_labels_end = '+'
        else:
            prediction_labels_end = '-'
        write_tp.append([str(num), str(id_all[num]), str(probs[num])])
    df = pd.DataFrame(write_tp, columns=['num', 'seq_id', 'prob'])
    if not os.path.exists(model_path):
        os.makedirs(model_path)
    df.to_excel('./' + model_path + '/result.xlsx',index=False)



    return None

if __name__ == "__main__":

    parser = argparse.ArgumentParser()

    parser.add_argument("-model", required=True,
                        choices=["humanbrain","humankidney","humanliver","human","mousebrain","mousekidney","mouseliver","mouseheart","mousetestis","mouse","ratbrain","ratkidney","ratliver","rat"],
                        help="the encoding type")
    parser.add_argument("-test_fasta", action="store", dest='test_fasta', required=True,
                        help="test fasta file")
    parser.add_argument("-out_dir", action="store", dest='out_dir', required=True,
                        help="output directory")

    args = parser.parse_args()
    test_fa = args.test_fasta
    model_name = args.model
#    print(model_name)
#    print(type(model_name))
    model_path = args.out_dir
    get_predictor(model_name,test_fa,model_path)

